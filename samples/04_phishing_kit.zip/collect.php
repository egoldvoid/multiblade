<?php $data=$_POST; file_put_contents('log.txt', json_encode($data), FILE_APPEND); ?>
