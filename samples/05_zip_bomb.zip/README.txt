Totally normal archive, nothing to see here.
