This archive is for testing the VirusTotal integration.
The file 'eicar.com' contains the EICAR standard antivirus test string.
It is harmless but will be flagged by all AV engines and VirusTotal.
SHA-256: 275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f
