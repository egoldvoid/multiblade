Internal security testing toolkit
