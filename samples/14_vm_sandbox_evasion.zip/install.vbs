strComputer = "."
Set objWMIService = GetObject("winmgmts:\\" & strComputer & "\root\subscription")
Set objEventFilter = objWMIService.Get("__EventFilter")
filterInstance.Query = "SELECT * FROM __InstanceModificationEvent WITHIN 60"
Set objConsumer = objWMIService.Get("ActiveScriptEventConsumer")
Set objBinding = objWMIService.Get("__FilterToConsumerBinding")
