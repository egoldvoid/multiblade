Please run install.bat to extract documents.
