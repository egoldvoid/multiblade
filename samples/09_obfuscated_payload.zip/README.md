Configuration bundle v2.1 - do not distribute
