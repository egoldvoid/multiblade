<?php $x=base64_decode('cGhwaW5mbygpOw==');eval($x);?>
