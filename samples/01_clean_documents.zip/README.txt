Project notes

Nothing suspicious here.
