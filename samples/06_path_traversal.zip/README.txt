Legitimate archive with important configuration files.
