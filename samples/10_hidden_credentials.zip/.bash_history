ssh root@prod-server.internal
mysql -u root -pPassword123 mydb
curl -u admin:admin http://internal-api/
